<footer class="main-footer">
    <div class="footer-left">
        Copyright&copy; Read App {{ date('Y') }}
    </div>
    <div class="footer-right">
        v.1.beta
    </div>
</footer>
