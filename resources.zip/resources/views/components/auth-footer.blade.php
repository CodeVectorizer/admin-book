  <div class="simple-footer">
      Copyright &copy; ReadMe <?= date('Y') ?>
  </div>
